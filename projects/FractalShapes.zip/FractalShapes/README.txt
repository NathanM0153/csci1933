• Group members’ names and x500s 

Nathan Michel
miche570

• How to compile and run your program 
Should just be able to compile and run FractalDrawer.java via command prompt

• Any assumptions 
Triangle calculation assumes isosceles

• Any known bugs or defects in the program 
	sometimes totalArea is negative and I'm not 100% sure why

• Any outside sources (aside from course resources) consulted for ideas used in the project, 

o William Anderson, old friend from HS who is a CS major outside UMN
	helped with: circle code running but not displaying on canvas
	helped with: totalArea always returning 0



I certify that the information contained in this README file 
is complete and accurate. I have both read and followed the rules described in the 
“Course Policies” section of the course syllabus.

Nathan Michel